/*
*This is auto generated from the ControlManifest.Input.xml file
*/

// Define IInputs and IOutputs Type. They should match with ControlManifest.
export interface IInputs {
    recordId: ComponentFramework.PropertyTypes.StringProperty;
    emailDataSet: ComponentFramework.PropertyTypes.DataSet;
}
export interface IOutputs {
}
